Szablon pracy dyplomowej dla Latexa.

Szablon wstępnie skonfigurowany dla Linuxa. W przypadku korzystania z MS-Windows należy zmienić fonty "Nimbus Roman No9" na "Times New Roman" we wszystkich używanych Stylach.
