Szablon pracy dyplomowej dla Latexa.

Szablon wstępnie skonfigurowany dla Linuxa. W przypadku korzystania z MS-Windows należy zmienić linie definiujące kodowanie tekstu źródłowego w plikach pwtitle.sty i style.txt. Zamiast Latin2 użyć cp1250.
